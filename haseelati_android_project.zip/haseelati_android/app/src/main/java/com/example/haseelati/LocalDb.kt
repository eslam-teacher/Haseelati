package com.example.haseelati

import android.content.Context
import net.sqlcipher.database.SQLiteDatabase
import java.io.File

data class Student(val id: Long, val name: String, val subject: String, val phone: String,
                   val rate: Double, val mode: String, val monthlyFee: Double)

class LocalDb(context: Context, passphrase: ByteArray) {
    private val db: SQLiteDatabase
    init {
        SQLiteDatabase.loadLibs(context)
        val file: File = context.getDatabasePath("haseelati.db")
        file.parentFile?.mkdirs()
        db = SQLiteDatabase.openOrCreateDatabase(file, passphrase.toString(Charsets.UTF_8), null)
        db.execSQL("CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, subject TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '', rate REAL NOT NULL DEFAULT 0, mode TEXT NOT NULL DEFAULT 'PER_LESSON', monthly_fee REAL NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE IF NOT EXISTS lessons(id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL, lesson_date TEXT NOT NULL, amount REAL NOT NULL, note TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL, paid_date TEXT NOT NULL, amount REAL NOT NULL, note TEXT NOT NULL DEFAULT '')")
    }
    fun addStudent(name: String, subject: String, phone: String, rate: Double, mode: String, monthlyFee: Double) {
        db.execSQL("INSERT INTO students(name,subject,phone,rate,mode,monthly_fee) VALUES(?,?,?,?,?,?)",
            arrayOf(name, subject, phone, rate, mode, monthlyFee))
    }
    fun students(): List<Student> {
        val out = mutableListOf<Student>()
        db.rawQuery("SELECT id,name,subject,phone,rate,mode,monthly_fee FROM students ORDER BY name", null).use { c ->
            while (c.moveToNext()) out.add(Student(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getDouble(4), c.getString(5), c.getDouble(6)))
        }
        return out
    }
    fun addLesson(studentId: Long, date: String, amount: Double, note: String = "") {
        db.execSQL("INSERT INTO lessons(student_id,lesson_date,amount,note) VALUES(?,?,?,?)", arrayOf(studentId, date, amount, note))
    }
    fun addPayment(studentId: Long, date: String, amount: Double, note: String = "") {
        db.execSQL("INSERT INTO payments(student_id,paid_date,amount,note) VALUES(?,?,?,?)", arrayOf(studentId, date, amount, note))
    }
    fun totals(s: Student): Triple<Double, Double, Double> {
        val due = if (s.mode == "MONTHLY") s.monthlyFee else scalar("SELECT COALESCE(SUM(amount),0) FROM lessons WHERE student_id=?", s.id)
        val paid = scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE student_id=?", s.id)
        return Triple(due, paid, due - paid)
    }
    private fun scalar(sql: String, id: Long): Double {
        db.rawQuery(sql, arrayOf(id.toString())).use { c -> if (c.moveToFirst()) return c.getDouble(0) }
        return 0.0
    }
    fun close() = db.close()
}
