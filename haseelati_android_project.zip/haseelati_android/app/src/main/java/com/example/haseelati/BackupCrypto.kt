package com.example.haseelati

import java.io.ByteArrayOutputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object BackupCrypto {
    // Format: HSL1 + salt(16) + IV(12) + AES-GCM ciphertext.
    fun encrypt(plain: ByteArray, password: CharArray): ByteArray {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(derive(password, salt), "AES"), GCMParameterSpec(128, iv))
        return ByteArrayOutputStream().apply {
            write("HSL1".toByteArray(Charsets.US_ASCII)); write(salt); write(iv); write(cipher.doFinal(plain))
        }.toByteArray()
    }
    fun decrypt(data: ByteArray, password: CharArray): ByteArray {
        require(data.size > 32 && String(data.copyOfRange(0, 4), Charsets.US_ASCII) == "HSL1") { "ملف النسخة غير صحيح" }
        val salt = data.copyOfRange(4, 20)
        val iv = data.copyOfRange(20, 32)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(derive(password, salt), "AES"), GCMParameterSpec(128, iv))
        return cipher.doFinal(data.copyOfRange(32, data.size))
    }
    private fun derive(password: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password, salt, 220000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }
}
