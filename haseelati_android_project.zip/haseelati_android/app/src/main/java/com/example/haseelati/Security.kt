package com.example.haseelati

import android.content.Context
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object Security {
    private const val PREFS = "haseelati_security"
    fun hasPin(c: Context) = c.getSharedPreferences(PREFS, 0).contains("pin_hash")
    fun savePin(c: Context, pin: String) {
        require(pin.length >= 6 && pin.all { it.isDigit() }) { "استخدم رقمًا سريًا من 6 أرقام على الأقل." }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = derive(pin, salt)
        c.getSharedPreferences(PREFS, 0).edit()
            .putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", Base64.encodeToString(hash, Base64.NO_WRAP)).apply()
    }
    fun verifyPin(c: Context, pin: String): Boolean = try {
        val p = c.getSharedPreferences(PREFS, 0)
        val salt = Base64.decode(p.getString("pin_salt", "")!!, Base64.NO_WRAP)
        val expected = Base64.decode(p.getString("pin_hash", "")!!, Base64.NO_WRAP)
        java.security.MessageDigest.isEqual(expected, derive(pin, salt))
    } catch (_: Exception) { false }

    fun dbKey(c: Context, pin: String): ByteArray {
        val p = c.getSharedPreferences(PREFS, 0)
        var saltText = p.getString("db_salt", null)
        if (saltText == null) {
            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            saltText = Base64.encodeToString(salt, Base64.NO_WRAP)
            p.edit().putString("db_salt", saltText).apply()
        }
        return derive(pin, Base64.decode(saltText, Base64.NO_WRAP))
    }
    private fun derive(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 180000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }
}
