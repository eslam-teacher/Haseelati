package com.example.haseelati

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private var db: LocalDb? = null
    private val money = NumberFormat.getNumberInstance(Locale("ar"))
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Reminder.schedule(this)
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 77)
        }
        if (Security.hasPin(this)) unlockDialog() else pinDialog(true)
    }
    private fun pinDialog(create: Boolean) {
        val input = EditText(this).apply { hint = "رقم سري من 6 أرقام"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle(if (create) "إنشاء رقم سري" else "فتح حصيلتي").setView(input).setCancelable(false)
            .setPositiveButton(if (create) "حفظ" else "فتح") { _, _ ->
                val pin = input.text.toString()
                if (create) {
                    try { Security.savePin(this, pin); open(pin) }
                    catch (e: Exception) { toast(e.message ?: "رقم سري غير صالح"); pinDialog(true) }
                } else if (Security.verifyPin(this, pin)) open(pin)
                else { toast("الرقم السري غير صحيح"); unlockDialog() }
            }.show()
    }
    private fun unlockDialog() {
        val input = EditText(this).apply { hint = "الرقم السري"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        val dialog = AlertDialog.Builder(this).setTitle("فتح حصيلتي").setView(input).setPositiveButton("فتح", null).setNeutralButton("البصمة", null).setCancelable(false).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val pin = input.text.toString()
                if (Security.verifyPin(this, pin)) { dialog.dismiss(); open(pin) } else input.error = "الرقم السري غير صحيح"
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                if (BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) != BiometricManager.BIOMETRIC_SUCCESS) {
                    toast("البصمة غير متاحة أو غير مفعلة")
                } else {
                    val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                            toast("نجح التحقق بالبصمة. أدخل الرقم السري لفتح قاعدة البيانات في هذا الإصدار.")
                        }
                    })
                    prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("التحقق بالبصمة")
                        .setSubtitle("التحقق لا يغني عن إدخال الرقم السري في هذا الإصدار")
                        .setNegativeButtonText("إلغاء").build())
                }
            }
        }
        dialog.show()
    }
    private fun open(pin: String) {
        try { db = LocalDb(this, Security.dbKey(this, pin)); home() }
        catch (_: Exception) { toast("تعذر فتح قاعدة البيانات. لا تمسح بيانات التطبيق."); unlockDialog() }
    }
    private fun layout(title: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 24, 20, 20)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
        root.addView(TextView(this).apply { text = title; textSize = 26f; setPadding(0,0,0,16) })
        return root
    }
    private fun button(root: LinearLayout, label: String, action: () -> Unit) {
        root.addView(Button(this).apply { text = label; setOnClickListener { action() } })
    }
    private fun home() {
        val root = layout("حصيلتي")
        root.addView(TextView(this).apply { text = "بيانات محلية — لا يتطلب التطبيق اتصالًا بالإنترنت"; textSize = 16f })
        button(root, "إضافة طالب") { addStudent() }
        button(root, "الطلاب والحسابات") { showStudents() }
        button(root, "إعادة جدولة تذكير يوم 27") { Reminder.schedule(this); toast("تمت الجدولة") }
        button(root, "النسخ الاحتياطي") { AlertDialog.Builder(this).setTitle("النسخ الاحتياطي").setMessage("تشفير AES-GCM موجود كوظيفة برمجية، لكن ربط تصدير واستعادة قاعدة البيانات بالواجهة لم يُستكمل بعد. لا تعتمد على هذا الإصدار لحفظ بيانات حقيقية.").setPositiveButton("حسنًا", null).show() }
        setContentView(root)
    }
    private fun field(h: String, numeric: Boolean = false) = EditText(this).apply {
        hint = h
        if (numeric) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    }
    private fun addStudent() {
        val name = field("اسم الطالب"); val subject = field("المادة"); val phone = field("الهاتف اختياري")
        val rate = field("سعر الحصة", true); val monthly = field("الاشتراك الشهري", true)
        val mode = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("الحساب بعدد الحصص", "اشتراك شهري ثابت")) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,8,20,8); addView(name); addView(subject); addView(phone); addView(rate); addView(monthly); addView(mode) }
        AlertDialog.Builder(this).setTitle("إضافة طالب").setView(box).setPositiveButton("حفظ") { _, _ ->
            if (name.text.isNullOrBlank() || subject.text.isNullOrBlank()) { toast("أدخل اسم الطالب والمادة"); return@setPositiveButton }
            db?.addStudent(name.text.toString(), subject.text.toString(), phone.text.toString(),
                rate.text.toString().toDoubleOrNull() ?: 0.0, if (mode.selectedItemPosition == 1) "MONTHLY" else "PER_LESSON",
                monthly.text.toString().toDoubleOrNull() ?: 0.0)
            home()
        }.setNegativeButton("إلغاء", null).show()
    }
    private fun showStudents() {
        val root = layout("الطلاب والحسابات")
        val students = db?.students().orEmpty()
        if (students.isEmpty()) root.addView(TextView(this).apply { text = "لا يوجد طلاب بعد." })
        students.forEach { s ->
            val t = db?.totals(s) ?: Triple(0.0,0.0,0.0)
            root.addView(TextView(this).apply {
                text = "${s.name} — ${s.subject}\nالمستحق: ${money.format(t.first)} | المدفوع: ${money.format(t.second)} | المتبقي: ${money.format(t.third)}"
                textSize = 16f; setPadding(8,14,8,14)
            })
            button(root, "إضافة حصة أو دفعة — ${s.name}") { transaction(s) }
        }
        button(root, "رجوع") { home() }
        setContentView(root)
    }
    private fun transaction(s: Student) {
        val kind = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("تسجيل حصة", "تسجيل دفعة")) }
        val amount = field("المبلغ", true); val note = field("ملاحظة اختياري")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(kind); addView(amount); addView(note) }
        AlertDialog.Builder(this).setTitle(s.name).setView(box).setPositiveButton("حفظ") { _, _ ->
            val value = amount.text.toString().toDoubleOrNull()
            if (value == null || value < 0) { toast("أدخل مبلغًا صحيحًا"); return@setPositiveButton }
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            if (kind.selectedItemPosition == 0) db?.addLesson(s.id, date, if (value == 0.0) s.rate else value, note.text.toString())
            else db?.addPayment(s.id, date, value, note.text.toString())
            showStudents()
        }.setNegativeButton("إلغاء", null).show()
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() { db?.close(); db = null; super.onDestroy() }
}
